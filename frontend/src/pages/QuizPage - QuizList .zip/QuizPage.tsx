import { useEffect, useState } from "react";
import axios from "axios";

import QuizGame from "./QuizGame"

export default function QuizPage() {
  return <QuizGame />
}

/*
export default function QuizPage() {

  const [quizzes, setQuizzes] = useState<any[]>([]);

  useEffect(() => {
    axios.get("http://localhost:3000/quizzes")
      .then(res => {
        setQuizzes(res.data);
      });
  }, []);

  return <QuizPage />;
}
*/