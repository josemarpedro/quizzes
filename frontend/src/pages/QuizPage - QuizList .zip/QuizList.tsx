import { useEffect, useState } from 'react';
import api from '../services/api';

export interface Quiz {
  id: string;
  countryName: string;
  correctContinent: string;
}

interface QuizListProps {
  onSelectQuiz: (quiz: Quiz) => void;
}

export function QuizList({ onSelectQuiz }: QuizListProps) {
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const load = async () => {
      try {
        setLoading(true);
        const response = await api.get<Quiz[]>('/quizzes');
        setQuizzes(response.data);
      } catch {
        setError('Não foi possível carregar os quizzes.');
      } finally {
        setLoading(false);
      }
    };

    load();
  }, []);

  if (loading) {
    return <p>Carregando quizzes...</p>;
  }

  if (error) {
    return <p>{error}</p>;
  }

  return (
    <div>
      <h1>Quizzes de Países e Continentes</h1>
      <p>Escolha um país para responder em qual continente ele está.</p>
      <ul>
        {quizzes.map((quiz) => (
          <li key={quiz.id}>
            <button type="button" onClick={() => onSelectQuiz(quiz)}>
              Jogar: {quiz.countryName}
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

